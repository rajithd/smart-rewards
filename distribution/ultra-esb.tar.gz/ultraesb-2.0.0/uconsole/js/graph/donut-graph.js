/**
 * @author Ruwan
 */
function donutGraph(divClass, w, h, stream) {
    var radius = Math.min(w, h) / 2;

    var color = d3.scale
        .category20b();
//        .ordinal()
//        .range(["#E6E2AF", "#A7A37E", "#EFECCA", "#046380", "#002F2F"]);

    var arc = d3.svg.arc()
        .outerRadius(radius - 10)
        .innerRadius(radius - 40);

    var pie = d3.layout.pie()
        .sort(null)
        .value(function(d) { return d.relativeAverage; });

    var svg = d3.select("div ." + divClass).append("svg")
        .attr("width", w)
        .attr("height", h)
        .append("g")
        .attr("transform", "translate(" + w / 2 + "," + h / 2 + ")");

    d3.json(getCallURLBase() + "metrics/retrieveAllTimeEvents/" + stream, function(error, raw) {
        var data = [];
        var i = 0;
        $.each(raw.events, function(t) {
            raw.events[t].i = i;
            data[i++] = raw.events[t];
        });

        data.sort(function(a, b) { return b.relativeAverage - a.relativeAverage; });

//        var min = d3.min(data, function(d) { return d.relativeAverage; });
//        data.forEach(function (d, i) {
//            d.relativeAverage = (d.relativeAverage - min)/1000000;
//        });

//        data.forEach(function(d) {
//            d.population = +d.population;
//        });

        var g = svg.selectAll(".arc")
            .data(pie(data))
            .enter().append("g")
            .attr("class", "arc");

        g.append("path")
            .attr("d", arc)
            .style("fill", function(d) { return color(d.data.i); });

        g.append("text")
            .attr("transform", function(d) { return "translate(" + arc.centroid(d) + ")"; })
            .attr("dy", ".35em")
            .style("text-anchor", "middle")
            .text(function(d) { return d.data.event; });

    });
}
