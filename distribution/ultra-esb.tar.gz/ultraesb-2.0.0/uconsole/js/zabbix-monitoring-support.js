/**
 * Zabbix monitoring template management and registration related functions
 * @author Ruwan
 */

function editTemplate(templateKey) {
    window.location.href = 'index.html?pageName=monitoring/template-details.html&templateKey=' + templateKey + '&mode=edit&bc=3';
}

function removeTemplate(templateKey) {
    showConfirmation("Do you want to remove the template with key : " + templateKey, function() {
        $.ajax({
            type: 'DELETE',
            url: getCallURLBase() + 'uz/templates/' + templateKey,
            success: function(msg) {
                showInfo("Successfully removed the template with key : " + templateKey, 'index.html?pageName=monitoring/uz-template-registry.html&bc=2');
            }
        });
    });
}

function enableTemplate(templateKey) {
    showConfirmation("Do you want to enable the template with key : " + templateKey, function() {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'uz/templates/' + templateKey + '/enable',
            success: function(msg) {
                showInfo("Successfully enabled the template with key : " + templateKey, window.location.href);
            }
        });
    });
}

function disableTemplate(templateKey) {
    showConfirmation("Do you want to disable the template with key : " + templateKey, function() {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'uz/templates/' + templateKey + '/disable',
            success: function(msg) {
                showInfo("Successfully disabled the template with key : " + templateKey, window.location.href);
            }
        });
    });
}
