function startProxyService(id,state) {

    if (state == 'Starting' ||state == 'Started') {
        showWarning('Cannot start proxy service: ' + id + ', is either started or starting.');
    } else {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'proxyservices/startProxyService/' +id ,
            success: function(msg) {
                showInfo('Successfully started the Proxy Service: ' + id + '.' , window.location.href);
            }
        });
    }
}

function stopProxyService(id,state) {

    if(state == 'Stopping' || state == 'Stopped' || state == 'Paused') {
        showWarning('Cannot stop the proxy service: ' + id + ', is either stopped or stopping.');
    } else {
        showConfirmation('Do you want to stop the Proxy Service ' + id + '?' , function() {
            $.ajax({
                type: 'POST',
                url: getCallURLBase() + 'proxyservices/stopProxyService/' +id ,
                success: function(msg) {
                    showInfo('Successfully stopped the Proxy Service: ' + id + '.' , window.location.href);
                }
            });
        });
    }
}

function enableDebugProxyService(id,debug) {

    if (!debug) {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'proxyservices/enableProxyServiceDebug/' +id ,
            success: function(msg) {
                showInfo('Debug successfully enabled for: ' + id + '.' , window.location.href);
            }
        });
    } else {
        showWarning('Debug enabled already!');
    }
}

function disableDebugProxyService(id,debug) {
    if (debug) {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'proxyservices/disableProxyServiceDebug/' +id ,
            success: function(msg) {
                showInfo('Debug successfully disabled for: ' + id + '.' ,  window.location.href);
            }
        });
    } else {
        showWarning('Debug disabled already!');
    }
}

function displayDebugIcon(id, debug) {
    if(debug) {
        $('img#' + id + '-enDebug').hide();
        $('img#' + id + '-disDebug').show();
    } else {
        $('img#' + id + '-disDebug').hide();
        $('img#' + id + '-enDebug').show();
    }
}

function displayIcon(id, state) {
    if(state=='Started') {
        $('img#' + id + '-start').hide();
        $('img#' + id + '-stop').show();
    }
    if(state == 'Stopped') {
        $('img#' + id + '-start').show();
        $('img#' + id + '-stop').hide();
    }
}