function startEndpoint(state,id) {

    if (state == 'Starting' ||state == 'Started') {
        showWarning('Cannot start the Endpoint: ' + id + ', is either started or starting.');
    } else {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'endpoints/startEndpoint/' +id ,
            success: function(msg) {
                showInfo('Successfully started the Endpoint: ' + id + '.', window.location.href);
            }
        });
    }
}

function stopEndpoint(state,id) {

    if (state == 'Stopping' || state == 'Stopped') {
        showWarning('Cannot stop the Endpoint: ' + id + ', is either stopped or stopping.');
    } else {
        showConfirmation('Do you want to stop the Endpoint?', function() {
            $.ajax({
                type: 'POST',
                url: getCallURLBase() + 'endpoints/stopEndpoint/' +id ,
                success: function(msg) {
                    showInfo('Successfully stopped the Endpoint: ' + id + '.', window.location.href);
                }
            });
        });
    }
}

function enableDebug(id,debug) {

    if (!debug) {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'endpoints/enableEndpointDebug/' +id ,
            success: function(msg) {
                showInfo('Debug enabled successfully for the Endpoint : ' + id + '.', window.location.href);
            }
        });
    } else {
        showWarning('Debug already enabled for endpoint ' + id + '!');
    }
}

function disableDebug(id,debug) {

    if (debug) {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'endpoints/disableEndpointDebug/' +id ,
            success: function(msg) {
                showInfo('Debug disabled successfully for the Endpoint : ' + id + '.', window.location.href);
            }
        });
    } else {
        showWarning('Debug already disabled for endpoint ' + id + '!');
    }
}

function editEndpoint(id) {
    loadPage('index.html?pageName=node-mgt/endpoint-details.html&mode=edit&epId=' + id);
}

function startAddress(epId, id, state){
    if (state == 'active') {
        showWarning('Address ' + id + ' already started!');
    }
    else {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'endpoints/startAddress/' + epId + '/' + id,
            success: function(msg) {
                showInfo('Successfully started the Address: ' + id + ' of the endpoint ' + epId, window.location.href);
            }
        });
    }
}

function stopAddress(epId, id, state){
    if (state == 'off') {
        showWarning('Address: ' + id + ' already stopped!');
    }
    else {
        showConfirmation('Do you want to stop the address? ',function() {
            $.ajax({
                type: 'POST',
                url: getCallURLBase() + 'endpoints/stopAddress/' + epId + '/' + id ,
                success: function(msg) {
                    showInfo('Successfully stopped the Address: ' + id + ' of the endpoint ' + epId, window.location.href);
                }
            });
        });
    }
}

function editAddress(id1, id2) {
    loadPage('index.html?pageName=node-mgt/address.html&mode=edit&epId=' + id1 + '&type=' + type + '&addrId=' + id2);
}

function addAddress(id) {
    if (type == 'single') {
        showWarning('Cannot add a new address, address type - single.');
    }else{
        loadPage('index.html?pageName=node-mgt/address.html&mode=add&epId=' + id + '&type=' + type);
    }
}

function deleteAddress(epID, addrID, type, addrCount) {

    if (addrCount > 1) {
        if (type == 'single') {
            showWarning('Cannot Delete the Address: ' + addrID + ', address type-single.');

        } else {
            showConfirmation('Do you want to delete the address ' + addrID + ' of endpoint ' + epID + '?' , function() {
                $.ajax({
                    type: 'DELETE',
                    url: getCallURLBase() + 'endpoints/deleteAddress/' + epID + '/' + addrID ,
                    success: function(msg) {
                        showInfo('Successfully deleted the Address: ' + addrID + ' of endpoint ' + epID + '.', 'index.html?pageName=node-mgt/endpoint-details.html&mode=view&epId=' + epID);
                    }
                });
            });
        }
    } else {
         showWarning('Cannot Delete the Address: ' + addrID + ', the only existing address for ' + epID);
    }
}

function displayDebugIcon(id, debug) {
    if(debug) {
        $('img#' + id + '-enDebug').hide();
        $('img#' + id + '-disDebug').show();
    } else {
        $('img#' + id + '-disDebug').hide();
        $('img#' + id + '-enDebug').show();
    }
}

function displayIcon(id, state) {
    if(state=='Started') {
        $('img#' + id + '-start').hide();
        $('img#' + id + '-stop').show();
    }
    if(state == 'Stopped') {
        $('img#' + id + '-start').show();
        $('img#' + id + '-stop').hide();
    }
}