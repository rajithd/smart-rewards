function reTryCommand(commandId, nodeName) {
    showConfirmation("Do you want to retry the command " + commandId + " on node " + nodeName + "?", function() {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'cluster/retryCommand/' + commandId + "/" + nodeName,
            dataType: 'text',
            success: function(msg) {
                if (msg=="true") {
                    showInfo("Retry of the command " + commandId + " on node " + nodeName + " was successful.", window.location.href);
                } else {
                    showError("Retry of the command " + commandId + " on node " + nodeName + " failed!");
                }
            }
        }).error(function() {
            showError("Retry of the command " + commandId + " on node " + nodeName + " failed!");
        });
    });
}

function archiveCommand(commandId) {
    showConfirmation("Do you want to archive the command with id : " + commandId + "?", function() {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'cluster/archiveCommand/' + commandId,
            success: function(msg) {
                showInfo('Successfully archived the command with id : ' + commandId + '.', window.location.href);
            }
        });
    });
}

function rePublishCommand(commandId) {
    showConfirmation("Do you want to republish the command with id : " + commandId + "?", function() {
        $.ajax({
            type: 'POST',
            url: getCallURLBase() + 'cluster/republishCommand/' + commandId,
            dataType: 'text',
            success: function(msg) {
                showInfo('Successfully republished the command with id : ' + commandId + ' into a new command : ' + msg + '.', 'index.html?pageName=cluster-mgt/command-details.html&commandId=' + msg);
            }
        });
    });
}